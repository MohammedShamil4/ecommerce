from django.shortcuts import render,redirect
from django.http import HttpResponse, JsonResponse
from django.core.files.storage import FileSystemStorage
from web.models import *
import datetime
# Create your views here.

def main(request):
    return render(request, 'login.html')

def user_register(request):
    return render(request, 'register.html')


def authentication_login(request):

    username = request.POST['username']
    password = request.POST['password']

    # try:
    ob = Logins.objects.get(usernames=username, password=password)

    if ob is not None:
        if ob.user_type=='admin':
            return redirect('admin_pg')
        elif ob.user_type=='user':
            request.session['lid'] = ob.id
            return redirect('users_home')
        elif ob.user_type=='sales':
            request.session['lid'] = ob.id
            return redirect('sales_pg')
        else:
            request.session['lid'] = ob.id
            return redirect('purchase_pg')
    
    # except:
    #     return HttpResponse('''<script>alert('username or password mismatched');window.location="/"</script>''')


#admin dashboard
def admin_dashboard(request):
    return render(request, 'admin/admin_dash.html')


#admin home page
def admin_pg(request):
    ob = Products.objects.all()
    return render(request, 'admin/admin_index.html', {'val': ob})


#admin manage product page
def admin_manage_product(request):
    ob = Products.objects.all()
    return render(request, 'admin/manage.html', { 'val' : ob})

#admin product_adding page
def admin_product_adding(request):
    return render(request, 'admin/adding.html')


#adding to product table
def product_add(request):
    name = request.POST['product_name']
    category = request.POST['category']
    quantity = request.POST['quantity']
    price = request.POST['price']
    image = request.FILES['file']
    fs = FileSystemStorage()
    fp = fs.save(image.name, image)

    ob = Products()
    ob.name = name
    ob.image = image
    ob.category = category
    ob.quantity = quantity
    ob.price = price
    ob.save()

    return HttpResponse('''<script>alert("success");window.location="/admin_manage_product"</script>''')


#update product deatils
def update_product(request,id):
    ob = Products.objects.get(id=id)
    request.session['sid'] = id
    return render(request, 'admin/update.html', {'val': ob})

#updating existing product
def update_pdt(request):

    try:
        name = request.POST['product_name']
        category = request.POST['category']
        quantity = request.POST['quantity']
        price = request.POST['price']
        image = request.FILES['image']
        fs = FileSystemStorage()
        fp = fs.save(image.name, image)
    
        iob = Products.objects.get(id=request.session['sid'])
        iob.name = name
        iob.image = image
        iob.category = category
        iob.quantity = quantity
        iob.price = price
        iob.save()

        return HttpResponse('''<script>alert("success");window.location="/admin_manage_product"</script>''')

    except:
        name = request.POST['product_name']
        category = request.POST['category']
        quantity = request.POST['quantity']
        price = request.POST['price']

        iob = Products.objects.get(id=request.session['sid'])
        iob.name = name
        iob.category = category
        iob.quantity = quantity
        iob.price = price
        iob.save()

        return HttpResponse('''<script>alert("success");window.location="/admin_manage_product"</script>''')


#deleting existing product
def delete_product(request, id):

    iob = Products.objects.get(id=id)
    iob.delete()

    return HttpResponse('''<script>alert("success");window.location="/admin_manage_product"</script>''')


# -------------------------------------------------------------------------------------------------------------------

#user registeration
def insert_user(request):

    name = request.POST['user_name']
    address = request.POST['address']
    phone = request.POST['phone']
    username = request.POST['username']
    password = request.POST['password']

    ob = Logins()
    ob.usernames = username
    ob.password = password
    ob.user_type = 'user'
    ob.save()

    iob = Users()
    iob.user_id = ob
    iob.name = name
    iob.address = address
    iob.phone = phone
    iob.save()

    return HttpResponse('''<script>alert("success");window.location="/"</script>''')


#users home page
def users_home(request):
    ob = Products.objects.all()
    return render(request, 'user/user_index.html', {'val': ob})


# user dashboard
def users_dashboard(request):
    return render(request, 'user/user_dashboard.html')


# product cartlist
def product_cartlist(request, id):
    ob = Products.objects.get(id=id)
    request.session['sid'] = id
    return render(request, 'user/product_cart.html', {'val': ob})


# product cart order
def product_order(request):
    ob=Cart.objects.all()
    print(len(ob),ob)
    ob = Cart.objects.filter(user_id__user_id__id=request.session['lid'])
    print(len(ob),ob,request.session['lid'])
    quantity = request.POST['quantity']
    product_id = Products.objects.get(id= request.session['sid'])
    if len(ob) > 0:
        ob = ob[0]
    else:
        ob = Cart()
        ob.user_id = Users.objects.get(user_id__id=request.session['lid'])
        ob.date = datetime.datetime.today() 
        ob.amount = 0
        ob.save()
    iob = CartList()
    iob.cart_id = ob
    iob.product_id = product_id
    iob.quantity =quantity
    iob.save()
    p=int(product_id.price)*int(quantity)
    print(ob.amount,"=====================")
    ob.amount=int(ob.amount)+int(p)
    print(ob.amount,"===========================")
    ob.save()
    

    return HttpResponse('''<script>alert("success");window.location="users_home"</script>''')

#cartlist view
def view_cartlist(request):
    ob=CartList.objects.filter(cart_id__user_id__user_id__id=request.session['lid'])
    amt="0"
    if len(ob)>0:
        amt=ob[0].cart_id.amount
    return render(request, 'user/order_amt.html', {'val': ob,"amt":amt})

#cartlist remove item
def removes(request,id):
    ob = CartList.objects.get(id=id)
    print(ob)
    p=ob.quantity*ob.product_id.price
    ob1=ob.cart_id
    ob1.amount=ob1.amount-p
    ob1.save()
    ob.delete()
    
    return HttpResponse('''<script>alert("success");window.location="/view_cartlist"</script>''')


def empty_cart(request, id):
    print(id)
    ob = CartList.objects.get(id=id)
    maxi = ob.product_id.quantity
    mini = ob.quantity
    if int(maxi) >= int(mini):
        print("order placed")
        obb = ob.product_id
        obb.quantity = int(obb.quantity)-int(mini)
        obb.save()
        r = ob.quantity * ob.product_id.price
        ob1 = ob.cart_id
        ob1.amount = ob1.amount - r
        ob1.save()
        uid = Logins.objects.get(id=request.session['lid'])
        obj = SalesInvoice()
        obj.user_id = Users.objects.get(user_id=uid)
        obj.category = obb.category
        obj.product = obb.name
        obj.unit_price = obb.price
        obj.quantity = mini
        obj.total = r
        obj.save()
        ob.delete()

    else:
        print("cannot place order")
        return HttpResponse('''<script>alert("out of stock");window.location="/view_cartlist"</script>''')

    return HttpResponse('''<script>alert("success");window.location="/view_cartlist"</script>''')


def sales_dashboard(request):
    return render(request, 'sales/dash.html')


def sales_pg(request):
    ob = Products.objects.all()
    return render(request, 'sales/index.html', {'val': ob})


def search_invoice(request):

    product = request.POST['product']
    quantity = request.POST['quantity']
    if quantity is '':
        ob = SalesInvoice.objects.filter(product=product)
    else:
        ob = SalesInvoice.objects.filter(product=product,quantity=quantity)

    return render(request, 'sales/update.html',{'val': ob})


def purchase_dashboard(request):
    return render(request, 'purchase/dash.html')


def purchase_pg(request):
    return render(request, 'purchase/index.html')


def stck_flt(request):
    data = request.POST['select']
    ob = Products.objects.all()
    return render(request, 'purchase/index.html', {'val': ob, 'data': data})


def adding_stock(request,id):
    ob = Products.objects.get(id=id)
    request.session['sid'] = id
    return render(request, 'purchase/update.html', {'val': ob})


def new_stock(request):
    name = request.POST['product_name']
    category = request.POST['category']
    quantity = request.POST['quantity']
    price = request.POST['price']

    iob = Products.objects.get(id=request.session['sid'])
    iob.name = name
    iob.category = category
    iob.quantity = quantity
    iob.price = price
    iob.save()

    return HttpResponse('''<script>alert("success");window.location="/purchase_pg"</script>''')


from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def view_pagination(request):
    # Retrieve all data from your model
    all_data = Products.objects.all()

    # Set the number of items per page
    items_per_page = 2

    # Create a Paginator instance
    paginator = Paginator(all_data, items_per_page)

    # Get the current page number from the request's GET parameters
    page = request.GET.get('page')

    try:
        # Get the Page object for the requested page
        current_page = paginator.page(page)
    except PageNotAnInteger:
        # If the page parameter is not an integer, show the first page
        current_page = paginator.page(1)
    except EmptyPage:
        # If the requested page is out of range, show the last page
        current_page = paginator.page(paginator.num_pages)

    return render(request, 'admin/pagination.html', {'current_page': current_page})


