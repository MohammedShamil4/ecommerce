from django.shortcuts import render,redirect
from django.http import HttpResponse, JsonResponse
from django.db import IntegrityError
from django.core.files.storage import FileSystemStorage
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from web.models import *
import datetime
# Create your views here.


def logout(request):
    auth.logout(request)
    return redirect('/')


def main(request):
    return render(request, 'login.html')


def user_register(request):
    return render(request, 'register.html')


def authentication_login(request):

    username = request.POST['username']
    password = request.POST['password']

    try:
        ob = Logins.objects.get(usernames=username, password=password)

        if ob is not None:
            if ob.user_type=='admin':
                oob = auth.authenticate(username='admin', password='admin')
                auth.login(request, oob)
                if oob is not None:
                    return redirect('admin_pg')
            elif ob.user_type=='user':
                oob = auth.authenticate(username='admin', password='admin')
                auth.login(request, oob)
                if oob is not None:
                    request.session['lid'] = ob.id
                    return redirect('users_home')
            elif ob.user_type=='supplier':
                oob = auth.authenticate(username='admin', password='admin')
                auth.login(request, oob)
                if oob is not None:
                    request.session['lid'] = ob.id
                    return redirect('sales_pg')
            else:
                oob = auth.authenticate(username='admin', password='admin')
                auth.login(request, oob)
                if oob is not None:
                    request.session['lid'] = ob.id
                    return redirect('purchase_pg')

    except:
        return HttpResponse('''<script>alert('username or password mismatched');window.location="/"</script>''')


# admin dashboard
@login_required(login_url='/')
def admin_dashboard(request):
    return render(request, 'admin/admin_dash.html')


# admin home page
@login_required(login_url='/')
def admin_pg(request):
    ob = Products.objects.all()
    return render(request, 'admin/admin_index.html', {'val': ob})


# admin manage product page
@login_required(login_url='/')
def admin_manage_product(request):
    ob = Products.objects.all()
    return render(request, 'admin/manage.html', { 'val' : ob})


# admin product_adding page
@login_required(login_url='/')
def admin_product_adding(request):
    return render(request, 'admin/adding.html')


# adding to product table
@login_required(login_url='/')
def product_add(request):
    name = request.POST['product_name']
    category = request.POST['category']
    quantity = request.POST['quantity']
    price = request.POST['price']
    image = request.FILES['file']
    fs = FileSystemStorage()
    fp = fs.save(image.name, image)

    ob = Products()
    ob.name = name
    ob.image = image
    ob.category = category
    ob.quantity = quantity
    ob.price = price
    ob.save()

    return HttpResponse('''<script>alert("success");window.location="/admin_manage_product"</script>''')


# update product deatils
@login_required(login_url='/')
def update_product(request,id):
    ob = Products.objects.get(id=id)
    request.session['sid'] = id
    return render(request, 'admin/update.html', {'val': ob})

# updating existing product
@login_required(login_url='/')
def update_pdt(request):

    try:
        name = request.POST['product_name']
        category = request.POST['category']
        quantity = request.POST['quantity']
        price = request.POST['price']
        image = request.FILES['image']
        fs = FileSystemStorage()
        fp = fs.save(image.name, image)
    
        iob = Products.objects.get(id=request.session['sid'])
        iob.name = name
        iob.image = image
        iob.category = category
        iob.quantity = quantity
        iob.price = price
        iob.save()

        return HttpResponse('''<script>alert("success");window.location="/admin_manage_product"</script>''')

    except:
        name = request.POST['product_name']
        category = request.POST['category']
        quantity = request.POST['quantity']
        price = request.POST['price']

        iob = Products.objects.get(id=request.session['sid'])
        iob.name = name
        iob.category = category
        iob.quantity = quantity
        iob.price = price
        iob.save()

        return HttpResponse('''<script>alert("success");window.location="/admin_manage_product"</script>''')


# deleting existing product
@login_required(login_url='/')
def delete_product(request, id):

    iob = Products.objects.get(id=id)
    iob.delete()

    return HttpResponse('''<script>alert("success");window.location="/admin_manage_product"</script>''')


# -------------------------------------------------------------------------------------------------------------------

# user registeration
def insert_user(request):
    if request.method == 'POST':
        name = request.POST.get('user_name')
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Check if the username already exists
        if Logins.objects.filter(usernames=username).exists():
            alert_message = "Username is already taken. Please choose a different one."
            return HttpResponse(f'<script>alert("{alert_message}"); window.location="/"</script>')

        try:
            # Create a new login entry
            login_obj = Logins.objects.create(usernames=username, password=password, user_type='user')

            # Create a new user entry
            user_obj = Users.objects.create(user_id=login_obj, name=name, address=address, phone=phone)

            return HttpResponse('<script>alert("User registered successfully."); window.location="/"</script>')

        except IntegrityError as e:
            # Catch the integrity error and display an alert message
            alert_message = "An error occurred during user registration. Please try again."
            print(f"Error: {str(e)}")  # Print the error for debugging purposes
            return HttpResponse(f'<script>alert("{alert_message}"); window.location="/"</script>')

    return HttpResponse('<script>alert("Invalid request."); window.location="/"</script>')


# users home page
@login_required(login_url='/')
def users_home(request):
    ob = Products.objects.all()
    return render(request, 'user/user_index.html', {'val': ob})


# user dashboard
@login_required(login_url='/')
def users_dashboard(request):
    return render(request, 'user/user_dashboard.html')


# product cartlist
@login_required(login_url='/')
def product_cartlist(request, id):
    ob = Products.objects.get(id=id)
    request.session['sid'] = id
    return render(request, 'user/product_cart.html', {'val': ob})


# product cart order
@login_required(login_url='/')
def product_order(request):
    ob=Cart.objects.all()
    print(len(ob),ob)
    ob = Cart.objects.filter(user_id__user_id__id=request.session['lid'])
    print(len(ob),ob,request.session['lid'])
    quantity = request.POST['quantity']
    product_id = Products.objects.get(id= request.session['sid'])
    if len(ob) > 0:
        ob = ob[0]
    else:
        ob = Cart()
        ob.user_id = Users.objects.get(user_id__id=request.session['lid'])
        ob.date = datetime.datetime.today() 
        ob.amount = 0
        ob.save()
    iob = CartList()
    iob.cart_id = ob
    iob.product_id = product_id
    iob.quantity =quantity
    iob.save()
    p=int(product_id.price)*int(quantity)
    print(ob.amount,"=====================")
    ob.amount=int(ob.amount)+int(p)
    print(ob.amount,"===========================")
    ob.save()

    return HttpResponse('''<script>alert("success");window.location="users_home"</script>''')


# cartlist view
@login_required(login_url='/')
def view_cartlist(request):
    ob = CartList.objects.filter(cart_id__user_id__user_id__id=request.session['lid'])
    amt = "0"
    if len(ob)>0:
        amt=ob[0].cart_id.amount
    return render(request, 'user/order_amt.html', {'val': ob,"amt":amt})


# cartlist remove item
@login_required(login_url='/')
def removes(request,id):
    ob = CartList.objects.get(id=id)
    print(ob)
    p=ob.quantity*ob.product_id.price
    ob1=ob.cart_id
    ob1.amount=ob1.amount-p
    ob1.save()
    ob.delete()
    
    return HttpResponse('''<script>alert("success");window.location="/view_cartlist"</script>''')


@login_required(login_url='/')
def empty_cart(request, id):
    print(id)
    ob = CartList.objects.get(id=id)
    maxi = ob.product_id.quantity
    mini = ob.quantity
    if int(maxi) >= int(mini):
        print("order placed")
        obb = ob.product_id
        obb.quantity = int(obb.quantity)-int(mini)
        obb.save()
        r = ob.quantity * ob.product_id.price
        ob1 = ob.cart_id
        ob1.amount = ob1.amount - r
        ob1.save()
        uid = Logins.objects.get(id=request.session['lid'])
        obj = SalesInvoice()
        obj.user_id = Users.objects.get(user_id=uid)
        obj.category = obb.category
        obj.product = obb.name
        obj.unit_price = obb.price
        obj.date = datetime.datetime.today()
        obj.quantity = mini
        obj.total = r
        obj.save()
        ob.delete()

    else:
        print("cannot place order")
        return HttpResponse('''<script>alert("out of stock");window.location="/view_cartlist"</script>''')

    return HttpResponse('''<script>alert("success");window.location="/view_cartlist"</script>''')


@login_required(login_url='/')
def sales_dashboard(request):
    return render(request, 'supplier/dash.html')


@login_required(login_url='/')
def sales_pg(request):
    ob = Stocks.objects.all()
    return render(request, 'supplier/index.html', {'val': ob})


@login_required(login_url='/')
def search_invoice(request):

    product = request.POST['product']
    quantity = request.POST['quantity']
    if quantity is '':
        ob = SalesInvoice.objects.filter(product=product)
    else:
        ob = SalesInvoice.objects.filter(product=product,quantity=quantity)

    return render(request, 'supplier/update.html',{'val': ob})


@login_required(login_url='/')
def stck_flt(request):
    data = request.POST['select']
    ob = Stocks.objects.all()
    return render(request, 'supplier/index.html', {'val': ob, 'data': data})


@login_required(login_url='/')
def adding_stock(request,id):
    ob = Stocks.objects.get(id=id)
    request.session['sid'] = id
    return render(request, 'supplier/update.html', {'val': ob})


@login_required(login_url='/')
def new_stock(request):
    name = request.POST['product_name']
    category = request.POST['category']
    quantity = request.POST['quantity']
    price = request.POST['price']

    iob = Stocks.objects.get(id=request.session['sid'])
    iob.name = name
    iob.category = category
    iob.quantity = quantity
    iob.price = price
    iob.save()

    return HttpResponse('''<script>alert("success");window.location="/sales_pg"</script>''')


from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


@login_required(login_url='/')
def view_pagination(request):
    # Retrieve all data from your model
    all_data = Products.objects.all()

    # Set the number of items per page
    items_per_page = 2

    # Create a Paginator instance
    paginator = Paginator(all_data, items_per_page)

    # Get the current page number from the request's GET parameters
    page = request.GET.get('page')

    try:
        # Get the Page object for the requested page
        current_page = paginator.page(page)
    except PageNotAnInteger:
        # If the page parameter is not an integer, show the first page
        current_page = paginator.page(1)
    except EmptyPage:
        # If the requested page is out of range, show the last page
        current_page = paginator.page(paginator.num_pages)

    return render(request, 'admin/pagination.html', {'current_page': current_page})


@login_required(login_url='/')
def product_list(request):
    products = Products.objects.all()
    return render(request, 'admin/pg_fltr.html', {'products': products})


@login_required(login_url='/')
def user_invoice(request):
    id = request.session['lid']
    print(id)
    ob = SalesInvoice.objects.filter(user_id_id__user_id_id=id)
    return render(request, 'user/invoice_template.html',{'product': ob})


import os
from django.http import HttpResponse
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Image
from reportlab.lib.styles import getSampleStyleSheet
from io import BytesIO


@login_required(login_url='/')
def generate_invoice_report(request, id):
    # Your logic to fetch data for the invoice
    ob = SalesInvoice.objects.get(id=id)
    id = request.session['lid']
    obb = Users.objects.get(user_id=id)
    invoice_data = {
        'invoice_number': ob.id,
        'date': ob.date,
        'customer_name': obb.name,
        'customer_address': obb.address,
        'total_amount': ob.total,
        'items': [
            {'description': ob.product, 'quantity': ob.quantity, 'unit_price': ob.unit_price, 'total': ob.total},

        ],
        'shop_address': 'Grand hyper market, calicut',
        'shop_logo_path': 'static/assets/img/logo.png',  # Use a relative URL
        'terms_and_conditions': 'thank you for your purchase',
        'background_color': colors.lightgrey,
    }

    # Construct the absolute path
    shop_logo_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', invoice_data['shop_logo_path']))

    # Use the correct URL
    invoice_data['shop_logo_path'] = shop_logo_path.replace("\\", "/")

    # Create a BytesIO buffer to receive PDF data
    pdf_buffer = BytesIO()

    # Create the PDF object using the buffer and set the document title
    pdf = SimpleDocTemplate(pdf_buffer, pagesize=letter)

    # Create content for the PDF
    content = []

    # Add shop logo
    logo_path = invoice_data['shop_logo_path']
    if logo_path:
        logo = Image(logo_path, width=50, height=50)
        content.append(logo)

    # Add shop address
    shop_address_style = getSampleStyleSheet()['Heading2']
    content.append(Paragraph('Shop Address:', shop_address_style))
    content.append(Paragraph(invoice_data['shop_address'], shop_address_style))
    content.append(Paragraph('', shop_address_style))  # Empty line

    # Add customer details
    customer_style = getSampleStyleSheet()['Heading2']
    content.append(Paragraph('Customer Name:', customer_style))
    content.append(Paragraph(invoice_data['customer_name'], customer_style))
    content.append(Paragraph('Customer Address:', customer_style))
    content.append(Paragraph(invoice_data['customer_address'], customer_style))
    content.append(Paragraph('', customer_style))  # Empty line

    # Add a title
    title_style = getSampleStyleSheet()['Title']
    title = Paragraph('Invoice Report - {}'.format(invoice_data['invoice_number']), title_style)
    content.append(title)
    content.append(Paragraph('Date: {}'.format(invoice_data['date']), title_style))

    # Create a table for invoice items
    items_table_data = [
        ['Description', 'Quantity', 'Unit Price', 'Total']
    ]

    for item in invoice_data['items']:
        items_table_data.append([
            item['description'],
            str(item['quantity']),
            '{:.2f}'.format(item['unit_price']),
            '{:.2f}'.format(item['total']),
        ])

    items_table_data.append(['', '', 'Total Amount:', '{:.2f}'.format(invoice_data['total_amount'])])

    items_table = Table(items_table_data, colWidths=[250, 50, 100, 100])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), invoice_data['background_color']),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))

    content.append(items_table)

    # Add terms and conditions
    terms_style = getSampleStyleSheet()['BodyText']
    content.append(Paragraph('Terms and Conditions:', terms_style))
    content.append(Paragraph(invoice_data['terms_and_conditions'], terms_style))

    # Build the PDF
    pdf.build(content)

    # Get the value of the BytesIO buffer
    pdf_data = pdf_buffer.getvalue()
    pdf_buffer.close()

    # Create an HTTP response with the PDF content
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="invoice_report.pdf"'
    response.write(pdf_data)

    return response


@login_required(login_url='/')
def admin_newuser(request):
    ob = Users.objects.filter(user_id__user_type='supplier')
    return render(request, 'admin/manage_spg.html',{'val': ob})


@login_required(login_url='/')
def admin_addpage(request):
    return render(request, 'admin/new_supplier.html')


@login_required(login_url='/')
def inserting_users(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Check if the username already exists
        if Logins.objects.filter(usernames=username).exists():
            alert_message = "Username is already taken. Please choose a different one."
            return HttpResponse(f'<script>alert("{alert_message}"); window.location="/admin_addpage"</script>')

        try:
            # Create a new login entry
            login_obj = Logins.objects.create(usernames=username, password=password, user_type='supplier')

            # Create a new user entry
            user_obj = Users.objects.create(user_id=login_obj, name=name, address=address, phone=phone)

            return HttpResponse(
                '<script>alert("User registered successfully."); window.location="/admin_newuser"</script>')

        except IntegrityError as e:
            # Catch the integrity error and display an alert message
            alert_message = "An error occurred during user registration. Please try again."
            print(f"Error: {str(e)}")  # Print the error for debugging purposes
            return HttpResponse(f'<script>alert("{alert_message}"); window.location="/admin_newuser"</script>')

    return HttpResponse('<script>alert("Invalid request."); window.location="/admin_newuser"</script>')


@login_required(login_url='/')
def sup_pro(request):
    return render(request, 'supplier/sup_add.html')


@login_required(login_url='/')
def sup_data(request):
    name = request.POST['product_name']
    category = request.POST['category']
    quantity = request.POST['quantity']
    price = request.POST['price']

    ob = Stocks()
    ob.name = name
    ob.category = category
    ob.quantity = quantity
    ob.price = price
    ob.save()

    return HttpResponse('''<script>alert("success");window.location="/sales_pg"</script>''')


@login_required(login_url='/')
def delete_supp(request, id):
    iob = Stocks.objects.get(id=id)
    iob.delete()

    return HttpResponse('''<script>alert("success");window.location="/sales_pg"</script>''')


@login_required(login_url='/')
def stockpg(request):
    ob = Stocks.objects.all()
    return render(request, 'admin/buy_stock.html',{'val' :ob})


@login_required(login_url='/')
def ad_bystock(request, id):
    try:
        stock_obj = Stocks.objects.get(id=id)
        product_obj = Products.objects.filter(name=stock_obj.name).first()
        print(product_obj)
        image_path = "default.png"
        if product_obj:
            # Product already exists, update quantity and other fields
            product_obj.quantity = int(product_obj.quantity) + int(stock_obj.quantity)
            product_obj.save()
        else:
            # Product doesn't exist, create a new one
            Products.objects.create(
                name=stock_obj.name,
                category=stock_obj.category,
                quantity=stock_obj.quantity,
                price=stock_obj.price,
                image=image_path  # Assuming 'image' is the name of the image field
            )

        # Delete the stock object after processing
        stock_obj.delete()

    except Exception as e:
        # Handle exceptions, log errors, or perform necessary actions
        print(f"Error: {str(e)}")

    return HttpResponse('''<script>alert("success");window.location="/admin_pg"</script>''')